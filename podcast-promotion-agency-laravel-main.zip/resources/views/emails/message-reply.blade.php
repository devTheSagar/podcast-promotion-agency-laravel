<p>Hi,</p>

<p>{!! nl2br(e($bodyContent)) !!}</p>

<p>Best regards,<br>PodcastRank.net</p>