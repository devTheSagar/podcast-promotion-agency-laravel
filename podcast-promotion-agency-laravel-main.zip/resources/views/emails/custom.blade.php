<!DOCTYPE html>
<html>
<head>
    <title>{{ $subjectLine }}</title>
</head>
<body>
    {!! nl2br(e($messageContent)) !!}
</body>
</html>
